/*
   Copyright 2007 Attila Szegedi

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
package org.dynalang.mop.beans;

import java.beans.IntrospectionException;
import java.lang.reflect.UndeclaredThrowableException;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import org.dynalang.mop.BaseMetaobjectProtocol;
import org.dynalang.mop.CallProtocol;
import org.dynalang.mop.MetaobjectProtocol;

/**
 * A metaobject protocol implementation that allows access and manipulation of
 * POJOS using semantics adhering to the JavaBeans specification, as well as
 * access and manipulation of native Java arrays.
 * @author Attila Szegedi
 * @version $Id: $
 */
public class BeansMetaobjectProtocol implements MetaobjectProtocol {

    private final boolean methodsEnumerable;
    private final ConcurrentMap<Class, ClassMetaobjectProtocol> mops = 
        new ConcurrentHashMap<Class, ClassMetaobjectProtocol>();
    
    /**
     * Creates a new JavaBeans metaobject protocol that doesn't expose objects'
     * methods and JavaBeans properties as enumerable.
     */
    public BeansMetaobjectProtocol() {
	this(false);
    }
    
    /**
     * Creates a new JavaBeans metaobject protocol.
     * @param methodsEnumerable if true, then objects' methods and JavaBeans 
     * properties show up in the results of {@link #properties(Object)} and
     * {@link #propertyIds(Object)}. If false, these can still be accessed by
     * directly addressing them, but don't show up in aforementioned methods'
     * results. 
     */
    public BeansMetaobjectProtocol(boolean methodsEnumerable) {
	this.methodsEnumerable = methodsEnumerable;
    }
    
    public Object call(Object callable, CallProtocol callProtocol, 
            Map args) {
        // Java methods aren't callable with named arguments
        return Results.noAuthority;
    }

    public Object call(Object target, Object callableId, CallProtocol callProtocol, 
            Map args) {
        // Give chance to notFound etc. first
        Object result = callProtocol.get(target, callableId);
        if(result instanceof Results) {
            return result;
        }
        // Java methods aren't callable with named arguments
        return Results.noAuthority;
    }

    public Object call(Object target, Object callableId, CallProtocol callProtocol, 
            Object... args) {
        return getClassMetaobjectProtocol(target).call(target, callableId, 
                callProtocol, args);
    }

    public Object call(Object callable, CallProtocol callProtocol, 
            Object... args)
    {
        if(callable instanceof DynamicInstanceMethod) {
            return ((DynamicInstanceMethod)callable).call(args, 
                    callProtocol);
        }
        return Results.noAuthority;
    }

    public Results delete(Object target, long propertyId) {
        return has(target, propertyId) == Boolean.TRUE ? Results.notDeleteable : 
            Results.noAuthority;
    }

    public Results delete(Object target, Object propertyId) {
        return has(target, propertyId) == Boolean.TRUE ? Results.notDeleteable : 
            Results.noAuthority;
    }

    public Object get(Object target, long propertyId) {
        return getClassMetaobjectProtocol(target).get(target, propertyId);
    }

    public Object get(Object target, Object propertyId) {
        return getClassMetaobjectProtocol(target).get(target, propertyId);
    }

    public Boolean has(Object target, long propertyId) {
        return getClassMetaobjectProtocol(target).has(target, propertyId);
    }

    public Boolean has(Object target, Object propertyId) {
        return getClassMetaobjectProtocol(target).has(target, propertyId);
    }

    public Iterator<Map.Entry> properties(final Object target) {
        final ClassMetaobjectProtocol cmop = getClassMetaobjectProtocol(
                target);
        final Iterator<? extends Object> it = cmop.getPropertyIds(target);
        return new Iterator<Map.Entry>() {
            public boolean hasNext() {
                return it.hasNext();
            }
            
            public Entry<Object,Object> next() {
                final Object key = it.next();
                
                return new Map.Entry<Object,Object>() {
                    private boolean hasValue;
                    private Object value;
                    
                    public Object getKey() {
                        return key;
                    }
            
                    public Object getValue() {
                        if(!hasValue) {
                            value = cmop.get(target, key);
                            hasValue = true;
                        }
                        return value;
                    }
                    
                    public Object setValue(Object value) {
                        Object previousValue = cmop.get(target, key);
                        if(cmop.put(target, key, value, BeansMetaobjectProtocol.this) != Results.ok) {
                            throw new UnsupportedOperationException();
                        }
                        return previousValue;
                    }
                    
                    @Override
                    public int hashCode() {
                        Object value = getValue();
                        return 
                            (key == null ? 0 : key.hashCode()) ^ 
                            (value == null ? 0 : value.hashCode());
                    }
                    
                    @Override
                    public boolean equals(Object obj) {
                        if(!(obj instanceof Map.Entry)) {
                            return false;
                        }
                        Map.Entry e = (Map.Entry)obj;
                        Object value = getValue();
                        return (key == null ? e.getKey() == null : 
                            key.equals(e.getKey())) && (value == null ? 
                                    e.getValue() == null : 
                                        value.equals(e.getValue()));
                    }
                };
            }
            
            public void remove() {
                throw new UnsupportedOperationException();
            }
        };
    }

    public Iterator<? extends Object> propertyIds(Object target) {
        return getClassMetaobjectProtocol(target).getPropertyIds(target);
    }

    public Results put(Object target, long propertyId, Object value, CallProtocol callProtocol) {
        return getClassMetaobjectProtocol(target).put(target, propertyId, value, callProtocol);
    }

    public Results put(Object target, Object propertyId, Object value, CallProtocol callProtocol) {
        return getClassMetaobjectProtocol(target).put(target, propertyId, 
                value, callProtocol);
    }

    private static final Map<Class, PrimitiveConverter> primitiveConverters = 
        new IdentityHashMap<Class, PrimitiveConverter>();
    
    private static abstract class PrimitiveConverter {
        abstract Object representAs(Object object);
    }
    
    static {
        primitiveConverters.put(Boolean.TYPE, new PrimitiveConverter() {
            @Override Object representAs(Object object) {
                return object instanceof Boolean ? ((Boolean)object) : Results.noRepresentation;
            }
        });
        primitiveConverters.put(Byte.TYPE, new PrimitiveConverter() {
            @Override Object representAs(Object object) {
                return object instanceof Byte ? ((Byte)object) : Results.noRepresentation;
            }
        });
        primitiveConverters.put(Character.TYPE, new PrimitiveConverter() {
            @Override Object representAs(Object object) {
                return object instanceof Character ? ((Character)object) : Results.noRepresentation;
            }
        });
        primitiveConverters.put(Double.TYPE, new PrimitiveConverter() {
            @Override Object representAs(Object object) {
                if(object instanceof Double) {
                    return object;
                }
                if(object instanceof Integer || object instanceof Long || 
                        object instanceof Float || object instanceof Byte || 
                        object instanceof Short) {
                    return Double.valueOf(((Number)object).doubleValue());
                }
                if(object instanceof Character) {
                    return Double.valueOf(((Character)object).charValue());
                }
                return Results.noRepresentation;
            }
        });
        primitiveConverters.put(Float.TYPE, new PrimitiveConverter() {
            @Override Object representAs(Object object) {
                if(object instanceof Float) {
                    return object;
                }
                if(object instanceof Integer || object instanceof Long || 
                        object instanceof Byte || object instanceof Short) {
                    return Float.valueOf(((Number)object).floatValue());
                }
                if(object instanceof Character) {
                    return Float.valueOf(((Character)object).charValue());
                }
                return Results.noRepresentation;
            }
        });
        primitiveConverters.put(Integer.TYPE, new PrimitiveConverter() {
            @Override Object representAs(Object object) {
                if(object instanceof Integer) {
                    return object;
                }
                if(object instanceof Byte || object instanceof Short) {
                    return Integer.valueOf(((Number)object).intValue());
                }
                if(object instanceof Character) {
                    return Integer.valueOf(((Character)object).charValue());
                }
                return Results.noRepresentation;
            }
        });
        primitiveConverters.put(Long.TYPE, new PrimitiveConverter() {
            @Override Object representAs(Object object) {
                if(object instanceof Long) {
                    return object;
                }
                if(object instanceof Integer || object instanceof Byte || 
                        object instanceof Short) {
                    return Long.valueOf(((Number)object).longValue());
                }
                if(object instanceof Character) {
                    return Long.valueOf(((Character)object).charValue());
                }
                return Results.noRepresentation;
            }
        });
        primitiveConverters.put(Short.TYPE, new PrimitiveConverter() {
            @Override Object representAs(Object object) {
                if(object instanceof Short) {
                    return object;
                }
                if(object instanceof Byte) {
                    return Short.valueOf(((Number)object).shortValue());
                }
                return Results.noRepresentation;
            }
        });
        primitiveConverters.put(Void.TYPE, new PrimitiveConverter() {
            @Override Object representAs(Object object) {
                return Results.noRepresentation;
            }
        });
    }
    
    /**
     * In case object is an instance of the target class, returns it unchanged.
     * In case object is an instance of the boxing class for a primitive target
     * class, returns it unchanged. In case object is null and target class is
     * primitive, returns {@link BaseMetaobjectProtocol.Results#noRepresentation}.
     * In case the target class is primitive, and there exists a 
     * <a href="http://java.sun.com/docs/books/jls/third_edition/html/conversions.html#5.1.2">
     * widening primitive conversion</a> from the object's class unboxed 
     * primitive type to the target class, returns a boxed representation of 
     * the widened value. In all other cases, 
     * {@link BaseMetaobjectProtocol.Results#noRepresentation} is returned.
     */
    public Object representAs(Object object, Class targetClass) {
        // Object representations for primitive types are allowed
        if(targetClass.isPrimitive()) {
            if(object == null) {
                // null has no primitive representation
                return Results.noRepresentation;
            }
            return primitiveConverters.get(targetClass).representAs(object);
        }
        else if(object == null) {
            // null is a valid representation for all reference types
            return null;
        }
        // If the object is instance of the target class, it itself is the 
        // representation, otherwise there's no representation.
        return targetClass.isInstance(object) ? object : 
            Results.noRepresentation;
    }
    
    private ClassMetaobjectProtocol getClassMetaobjectProtocol(Object obj) {
        Class clazz = obj.getClass();
        ClassMetaobjectProtocol mop = mops.get(clazz);
        if(mop == null) {
            try {
        	if(clazz.isArray()) {
        	    mop = new ArrayClassMetaobjectProtocol(clazz, methodsEnumerable);
        	}
        	else {
        	    mop = new ClassMetaobjectProtocol(clazz, methodsEnumerable);
        	}
                mops.put(clazz, mop);
            }
            catch(IntrospectionException e) {
                throw new UndeclaredThrowableException(e);
            }
        }
        return mop;
    }
}