/*
   Copyright 2007 Attila Szegedi

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
package org.dynalang.mop.beans;

import java.lang.reflect.Member;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.dynalang.mop.CallProtocol;
import org.dynalang.mop.BaseMetaobjectProtocol.Results;

/**
 * @author Attila Szegedi
 * @version $Id: $
 */
class OverloadedFixArgMethod<T extends Member>
{
    private Class[][] marshalTypes;
    private final Map<ClassString, Object> selectorCache = 
        new ConcurrentHashMap<ClassString, Object>();
    private final List<T> members = new LinkedList<T>();
    
    void addMember(T member) {
        members.add(member);

        Class[] argTypes = OverloadedMethodUtilities.getParameterTypes(member);
        int l = argTypes.length;
        if(marshalTypes == null) {
            marshalTypes = new Class[l + 1][];
            marshalTypes[l] = argTypes;
        }
        else if(marshalTypes.length <= l) {
            Class[][] newMarshalTypes = new Class[l + 1][];
            System.arraycopy(marshalTypes, 0, newMarshalTypes, 0, marshalTypes.length);
            marshalTypes = newMarshalTypes;
            marshalTypes[l] = argTypes;
        }
        else {
            Class[] oldTypes = marshalTypes[l]; 
            if(oldTypes == null) {
                marshalTypes[l] = argTypes;
            }
            else {
                assert oldTypes.length == l;
                for(int i = 0; i < l; ++i) {
                    oldTypes[i] = OverloadedMethodUtilities.getMostSpecificCommonType(oldTypes[i], argTypes[i]);
                }
            }
        }
    }
    
    Object createInvocation(Object target, Object[] args, CallProtocol callProtocol) {
        if(args == null) {
            // null is treated as empty args
            args = DynamicMethod.NULL_ARGS;
        }
        int l = args.length;
        if(marshalTypes.length <= l) {
            return OverloadedDynamicMethod.NO_SUCH_METHOD;
        }
        Class[] types = marshalTypes[l];
        if(types == null) {
            return OverloadedDynamicMethod.NO_SUCH_METHOD;
        }
        assert types.length == l;
        // Marshal the arguments
        boolean argsCloned = false;
        for(int i = 0; i < l; ++i) {
            Object src = args[i];
            Object dst = callProtocol.representAs(src, types[i]);
            if(dst == Results.noAuthority || dst == Results.noRepresentation) {
                return OverloadedDynamicMethod.NO_SUCH_METHOD;
            }
            if(dst != src) {
                if(!argsCloned) {
                    args = args.clone();
                }
                args[i] = dst;
            }
        }
        ClassString<T> argTypes = new ClassString<T>(args);
        Object objMember = selectorCache.get(argTypes);
        if(objMember == null) {
            objMember = argTypes.getMostSpecific(members);
            selectorCache.put(argTypes, objMember);
        }
        if(objMember instanceof Member) {
            return new Invocation<T>(target, (T)objMember, args);
        }
        return objMember; // either NOT_FOUND or AMBIGUOUS
    }

    private static final class ClassString<T extends Member>
    {
        private final Class[] classes;
        
        ClassString(Object[] objects) {
            int l = objects.length;
            classes = new Class[l];
            for(int i = 0; i < l; ++i) {
                Object obj = objects[i];
                classes[i] = obj == null ? OverloadedMethodUtilities.OBJECT_CLASS : obj.getClass();
            }
        }
        
        Class[] getClasses() {
            return classes;
        }
        
        public int hashCode() {
            int hash = 0;
            for(int i = 0; i < classes.length; ++i) {
                hash ^= classes[i].hashCode();
            }
            return hash;
        }
        
        public boolean equals(Object o) {
            if(o instanceof ClassString) {
                ClassString cs = (ClassString)o;
                if(cs.classes.length != classes.length) {
                    return false;
                }
                for(int i = 0; i < classes.length; ++i) {
                    if(cs.classes[i] != classes[i]) {
                        return false;
                    }
                }
                return true;
            }
            return false;
        }
        
        private static final int MORE_SPECIFIC = 0;
        private static final int LESS_SPECIFIC = 1;
        private static final int INDETERMINATE = 2;
        
        Object getMostSpecific(List<T> methods)
        {
            LinkedList<T> applicables = getApplicables(methods);
            if(applicables.isEmpty()) {
                return OverloadedDynamicMethod.NO_SUCH_METHOD;
            }
            if(applicables.size() == 1) {
                return applicables.getFirst();
            }
            LinkedList<T> maximals = new LinkedList<T>();
            for (T applicable : applicables)
            {
                Class[] appArgs = OverloadedMethodUtilities.getParameterTypes(applicable);
                boolean lessSpecific = false;
                for (Iterator<T> maximal = maximals.iterator(); 
                    maximal.hasNext();)
                {
                    Member max = maximal.next();
                    Class[] maxArgs = OverloadedMethodUtilities.getParameterTypes(max);
                    switch(moreSpecific(appArgs, maxArgs)) {
                        case MORE_SPECIFIC: {
                            maximal.remove();
                            break;
                        }
                        case LESS_SPECIFIC: {
                            lessSpecific = true;
                            break;
                        }
                    }
                }
                if(!lessSpecific) {
                    maximals.addLast(applicable);
                }
            }
            if(maximals.size() > 1) {
                return OverloadedDynamicMethod.AMBIGUOUS_METHOD;
            }
            return maximals.getFirst();
        }
        
        private static int moreSpecific(Class[] c1, Class[] c2) {
            boolean c1MoreSpecific = false;
            boolean c2MoreSpecific = false;
            final int cl1 = c1.length;
            final int cl2 = c2.length;
            assert cl1 == cl2;
            for(int i = 0; i < cl1; ++i) {
                if(c1[i] != c2[i]) {
                    c1MoreSpecific = 
                        c1MoreSpecific ||
                        OverloadedMethodUtilities.isMoreSpecific(c1[i], c2[i]);
                    c2MoreSpecific = 
                        c2MoreSpecific ||
                        OverloadedMethodUtilities.isMoreSpecific(c2[i], c1[i]);
                }
            }
            if(c1MoreSpecific) {
                if(c2MoreSpecific) {
                    return INDETERMINATE;
                }
                return MORE_SPECIFIC;
            }
            if(c2MoreSpecific) {
                return LESS_SPECIFIC;
            }
            return INDETERMINATE;
        }
        
        /**
         * Returns all methods that are applicable to actual
         * parameter classes represented by this ClassString object.
         */
        LinkedList<T> getApplicables(List<T> methods) {
            LinkedList<T> list = new LinkedList<T>();
            for (T member : methods) {
                if(isApplicable(member)) {
                    list.add(member);
                }
            }
            return list;
        }
        
        /**
         * Returns true if the supplied method is applicable to actual
         * parameter classes represented by this ClassString object.
         * 
         */
        private boolean isApplicable(T member) {
            final Class[] formalTypes = OverloadedMethodUtilities.getParameterTypes(member);
            final int fl = formalTypes.length;
            final int cl = classes.length;
            if(fl != cl) {
                return false;
            }
            for(int i = 0; i < cl; ++i) {
                if(!isMethodInvocationConvertible(formalTypes[i], 
                        classes[i])) {
                    return false;
                }
            }
            return true;
        }
        
        /**
         * Determines whether a type represented by a class object is
         * convertible to another type represented by a class object using a 
         * method invocation conversion, treating object types of primitive 
         * types as if they were primitive types (that is, a Boolean actual 
         * parameter type matches boolean primitive formal type). This behavior
         * is because this method is used to determine applicable methods for 
         * an actual parameter list, and primitive types are represented by 
         * their object duals in reflective method calls.
         * @param formal the formal parameter type to which the actual 
         * parameter type should be convertible
         * @param actual the actual parameter type.
         * @return true if either formal type is assignable from actual type, 
         * or formal is a primitive type and actual is its corresponding object
         * type or an object type of a primitive type that can be converted to
         * the formal type.
         */
        private static boolean isMethodInvocationConvertible(Class<?> formal, Class<?> actual) {
            // Check for identity or widening reference conversion
            if(formal.isAssignableFrom(actual)) {
                return true;
            }
            // Check for boxing with widening primitive conversion. Note that 
            // actual parameters are never primitives.
            if(formal.isPrimitive()) {
                if(formal == Boolean.TYPE)
                    return actual == Boolean.class;
                if(formal == Character.TYPE)
                    return actual == Character.class;
                if(formal == Byte.TYPE && actual == Byte.class)
                    return true;
                if(formal == Short.TYPE &&
                   (actual == Short.class || actual == Byte.class))
                    return true;
                if(formal == Integer.TYPE && 
                   (actual == Integer.class || actual == Short.class || 
                    actual == Byte.class))
                    return true;
                if(formal == Long.TYPE && 
                   (actual == Long.class || actual == Integer.class || 
                    actual == Short.class || actual == Byte.class))
                    return true;
                if(formal == Float.TYPE && 
                   (actual == Float.class || actual == Long.class || 
                    actual == Integer.class || actual == Short.class || 
                    actual == Byte.class))
                    return true;
                if(formal == Double.TYPE && 
                   (actual == Double.class || actual == Float.class || 
                    actual == Long.class || actual == Integer.class || 
                    actual == Short.class || actual == Byte.class))
                    return true; 
            }
            return false;
        }
    }
}
