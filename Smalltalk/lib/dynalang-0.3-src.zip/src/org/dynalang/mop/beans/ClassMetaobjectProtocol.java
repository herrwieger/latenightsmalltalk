/*
   Copyright 2007 Attila Szegedi

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
package org.dynalang.mop.beans;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.MethodDescriptor;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.UndeclaredThrowableException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;

import org.dynalang.mop.CallProtocol;
import org.dynalang.mop.BaseMetaobjectProtocol.Results;

class ClassMetaobjectProtocol
{
    private final Map<String, PropertyDescriptor> properties = 
        new HashMap<String, PropertyDescriptor>();
    private final Map<String, DynamicMethod> methods = 
        new HashMap<String, DynamicMethod>();
    private final Collection<String> names;
    
    ClassMetaobjectProtocol(Class clazz, boolean methodsEnumerable) throws IntrospectionException {
        BeanInfo beanInfo = Introspector.getBeanInfo(clazz);
        Map<MethodSignature, Method> accessibleMethods = 
            discoverAccessibleMethods(clazz);
        PropertyDescriptor[] propDescs = beanInfo.getPropertyDescriptors();
        for (int i = 0; i < propDescs.length; i++) {
            PropertyDescriptor descriptor = propDescs[i];
            Method readMethod = descriptor.getReadMethod();
            if(readMethod != null) {
                descriptor.setReadMethod(getAccessibleMethod(readMethod, 
                        accessibleMethods));
            }
            Method writeMethod = descriptor.getWriteMethod();
            if(writeMethod != null) {
                descriptor.setWriteMethod(getAccessibleMethod(writeMethod, 
                        accessibleMethods));
            }
            if(descriptor.getReadMethod() != null || descriptor.getWriteMethod() != null) {
                properties.put(descriptor.getName(), descriptor);
            }
        }
        MethodDescriptor[] methodDescs = beanInfo.getMethodDescriptors();
        for (int i = 0; i < methodDescs.length; i++) {
            MethodDescriptor descriptor = methodDescs[i];
            Method method = getAccessibleMethod(descriptor.getMethod(), 
                    accessibleMethods);
            if(method == null) {
                continue;
            }
            String name = descriptor.getName();
            DynamicMethod dynaMethod = methods.get(name);
            if(dynaMethod == null) {
                methods.put(name, new SimpleDynamicMethod(method));
            }
            else if(dynaMethod instanceof SimpleDynamicMethod) {
                OverloadedDynamicMethod<Method> odm = 
                    new OverloadedDynamicMethod<Method>(name);
                odm.addMember(((SimpleDynamicMethod)dynaMethod).getMethod());
                odm.addMember(method);
                methods.put(name, odm);
            }
            else if(dynaMethod instanceof OverloadedDynamicMethod) {
                ((OverloadedDynamicMethod<Method>)dynaMethod).addMember(
                        method);
            }
        }
        if(methodsEnumerable) {
            Collection<String> cnames = new HashSet<String>(properties.size() + 
            	methods.size() * 4 / 3, 0.75f);
            cnames.addAll(properties.keySet());
            cnames.addAll(methods.keySet());
            // Sorting is not really necessary, but it's nice to make it 
            // deterministic and it doesn't cost that much
            ArrayList<String> lnames = new ArrayList<String>(cnames);
            Collections.sort(lnames);
            lnames.trimToSize();
            names = Collections.unmodifiableCollection(lnames);
        }
        else {
            names = Collections.emptySet();
        }
    }

    Object call(Object target, Object callableId, CallProtocol callProtocol, 
            Object[] args) {
        String name = String.valueOf(callableId);
        DynamicMethod dynaMethod = methods.get(name);
        if(dynaMethod == null) {
            return Results.noAuthority;
        }
        return dynaMethod.call(target, args, callProtocol);
    }

    Object get(Object target, long propertyId) {
        return Results.noAuthority;
    }
    
    Object get(Object target, Object propertyId) {
	String name = String.valueOf(propertyId);
        PropertyDescriptor desc = properties.get(name);
        if(desc == null) {
            DynamicMethod dynaMethod = methods.get(name);
            if(dynaMethod == null) {
                // No property and no method - doesn't exist
                return Results.noAuthority;
            }
            // Return instance-bound method
            return new DynamicInstanceMethod(target, dynaMethod);
        }
        
        Method method = desc.getReadMethod();
        if(method == null) {
            // Write-only property
            return Results.notReadable;
        }
        try {
            return method.invoke(target, (Object[])null);
        }
        catch(RuntimeException e) {
            throw e;
        }
        catch(Exception e) {
            throw new UndeclaredThrowableException(e);
        }
    }
    
    Boolean has(Object target, long propertyId) {
        return null;
    }
    
    Boolean has(Object target, Object propertyId) {
        String name = String.valueOf(propertyId);
        if(properties.containsKey(name) || methods.containsKey(name)) {
            return Boolean.TRUE;
        }
        return null;
    }
    
    Iterator<? extends Object> getPropertyIds(Object target) {
        return names.iterator();
    }
    
    Results put(Object target, long propertyId, Object value, CallProtocol callProtocol) {
        return Results.noAuthority;
    }

    Results put(Object target, Object propertyId, Object value, CallProtocol callProtocol) {
        PropertyDescriptor desc = properties.get(String.valueOf(propertyId));
        if(desc == null) {
            return Results.noAuthority;
        }
        Method writeMethod = desc.getWriteMethod();
        if(writeMethod == null) {
            return Results.notWritable;
        }
        try {
            Class propType = desc.getPropertyType();
            if(propType == null) {
                return Results.notWritable;
            }
            value = callProtocol.representAs(value, propType);
            if(value == Results.noAuthority || value == Results.noRepresentation) {
                return Results.noRepresentation;
            }
            writeMethod.invoke(target, new Object[] { value });
            return Results.ok;
        }
        catch(RuntimeException e) {
            throw e;
        }
        catch(Exception e) {
            throw new UndeclaredThrowableException(e);
        }
    }

    private static Map<MethodSignature, Method> discoverAccessibleMethods(Class clazz) {
        Map<MethodSignature, Method> map = new HashMap<MethodSignature, Method>();
        discoverAccessibleMethods(clazz, map);
        return map;
    }
    
    private static void discoverAccessibleMethods(Class clazz, Map<MethodSignature, Method> map) {
        if(Modifier.isPublic(clazz.getModifiers())) {
            try {
                Method[] methods = clazz.getMethods();
                for(int i = 0; i < methods.length; i++) {
                    Method method = methods[i];
                    MethodSignature sig = new MethodSignature(method);
                    map.put(sig, method);
                }
                return;
            }
            catch(SecurityException e) {
                System.err.println(
                        "Could not discover accessible methods of class " + 
                        clazz.getName() + ", attemping superclasses/interfaces.");
                e.printStackTrace();
                // Fall through and attempt to discover superclass/interface 
                // methods
            }
        }

        Class[] interfaces = clazz.getInterfaces();
        for(int i = 0; i < interfaces.length; i++) {
            discoverAccessibleMethods(interfaces[i], map);
        }
        Class superclass = clazz.getSuperclass();
        if(superclass != null) {
            discoverAccessibleMethods(superclass, map);
        }
    }

    private static Method getAccessibleMethod(Method m, Map<MethodSignature, Method> accessibles) {
        return m == null ? null : accessibles.get(new MethodSignature(m));
    }

    private static final class MethodSignature
    {
        private final String name;
        private final Class[] args;
        
        private MethodSignature(String name, Class[] args) {
            this.name = name;
            this.args = args;
        }
        
        MethodSignature(Method method) {
            this(method.getName(), method.getParameterTypes());
        }
        
        public boolean equals(Object o) {
            if(o instanceof MethodSignature) {
                MethodSignature ms = (MethodSignature)o;
                return ms.name.equals(name) && Arrays.equals(args, ms.args);
            }
            return false;
        }
        
        public int hashCode() {
            return name.hashCode() ^ Arrays.hashCode(args);
        }
    }
}