/*
   Copyright 2007 Attila Szegedi

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
package org.dynalang.mop.beans;

import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import org.dynalang.mop.CallProtocol;
import org.dynalang.mop.BaseMetaobjectProtocol.Results;

/**
 * @author Attila Szegedi
 * @version $Id: $
 */
class OverloadedVarArgMethod<T extends Member>
{
    private static final Class<Object> OBJECT_CLASS = Object.class;
    
    private Class[][] marshalTypes;
    private final Map<ClassString, Object> selectorCache = 
        new ConcurrentHashMap<ClassString, Object>();
    private final List<T> members = new LinkedList<T>();
    private final Map<T, ArgumentPacker> argPackers = new HashMap<T, ArgumentPacker>();
    
    private static class ArgumentPacker {
        private final int argCount;
        private final Class varArgType;
        
        ArgumentPacker(Class[] argTypes) {
            argCount = argTypes.length;
            varArgType = argTypes[argCount - 1].getComponentType(); 
        }
        
        Object[] packArgs(Object[] args, boolean cloned, CallProtocol callProtocol) {
            final int actualArgCount = args.length;
            final int fixArgCount = argCount - 1;
            if(args.length != argCount) {
                Object[] newargs = new Object[argCount];
                System.arraycopy(args, 0, newargs, 0, fixArgCount);
                Object array = Array.newInstance(varArgType, actualArgCount - fixArgCount);
                for(int i = fixArgCount; i < actualArgCount; ++i) {
                    Object val = callProtocol.representAs(args[i], varArgType);
                    if(val == Results.noRepresentation || val == Results.noAuthority) {
                        return null;
                    }
                    Array.set(array, i - fixArgCount, val);
                }
                newargs[fixArgCount] = array;
                return newargs;
            }
            Object val = callProtocol.representAs(args[fixArgCount], varArgType);
            if(val == Results.noRepresentation || val == Results.noAuthority) {
                return null;
            }
            Object array = Array.newInstance(varArgType, 1);
            Array.set(array, 0, val);
            if(!cloned) {
                args = args.clone();
            }
            args[fixArgCount] = array;
            return args;
        }
    }

    void addMember(T member) {
        members.add(member);

        Class[] argTypes = getParameterTypes(member);
        int l = argTypes.length;
        argPackers.put(member, new ArgumentPacker(argTypes));
        componentizeLastType(argTypes);
        if(marshalTypes == null) {
            marshalTypes = new Class[l + 1][];
            marshalTypes[l] = argTypes;
            updateFromSurroundingVarArg(l);
        }
        else if(marshalTypes.length <= l) {
            Class[][] newMarshalTypes = new Class[l + 1][];
            System.arraycopy(marshalTypes, 0, newMarshalTypes, 0, marshalTypes.length);
            marshalTypes = newMarshalTypes;
            marshalTypes[l] = argTypes;
            updateFromSurroundingVarArg(l);
        }
        else {
            Class[] oldTypes = marshalTypes[l]; 
            if(oldTypes == null) {
                marshalTypes[l] = argTypes;
            }
            else {
                for(int i = 0; i < oldTypes.length; ++i) {
                    oldTypes[l] = getMostSpecificCommonType(oldTypes[l], argTypes[l]);
                }
            }
            updateFromSurroundingVarArg(l);
        }

        // Since this member is vararg, its types influence the types in all
        // type specs longer than itself.
        Class[] newTypes = marshalTypes[l];
        for(int i = l + 1; i < marshalTypes.length; ++i) {
            Class[] existingTypes = marshalTypes[i];
            if(existingTypes != null) {
                varArgUpdate(existingTypes, newTypes);
            }
        }
        // It also influences the types in the marshal spec that is exactly
        // one argument shorter (as vararg methods can be invoked with 0
        // variable arguments, that is, with k-1 cardinality).
        if(l > 0) {
            Class[] oneShorterTypes = marshalTypes[l - 1];
            if(oneShorterTypes != null) {
                varArgUpdate(oneShorterTypes, newTypes);
            }
        }
    }
    
    private void updateFromSurroundingVarArg(int l) {
        Class[] newTypes = marshalTypes[l];
        // First vararg marshal type spec with less parameters than the 
        // current spec influences the types of the current marshal spec.
        for(int i = l; i-->0;) {
            Class[] previousTypes = marshalTypes[i];
            if(previousTypes != null) {
                varArgUpdate(newTypes, previousTypes);
                break;
            }
        }
        // Vararg marshal spec with exactly one parameter more than the current
        // spec influences the types of the current spec
        if(l + 1 < marshalTypes.length) {
            Class[] oneLongerTypes = marshalTypes[l + 1];
            if(oneLongerTypes != null) {
                varArgUpdate(newTypes, oneLongerTypes);
            }
        }
    }
    
    private static void varArgUpdate(Class[] modifiedTypes, Class[] modifyingTypes) {
        final int dl = modifiedTypes.length;
        final int gl = modifyingTypes.length;
        int min = Math.min(gl, dl);
        for(int i = 0; i < min; ++i) {
            modifiedTypes[i] = getMostSpecificCommonType(modifiedTypes[i], 
                    modifyingTypes[i]);
        }
        if(dl > gl) {
            Class varArgType = modifyingTypes[gl - 1];
            for(int i = gl; i < dl; ++i) {
                modifiedTypes[i] = getMostSpecificCommonType(modifiedTypes[i], 
                        varArgType);
            }
        }
    }
    
    private static void componentizeLastType(Class[] types) {
        int l1 = types.length - 1;
        assert l1 >= 0;
        assert types[l1].isArray();
        types[l1] = types[l1].getComponentType();
    }
    
    Object createInvocation(Object target, Object[] args, CallProtocol callProtocol) {
        if(args == null) {
            // null is treated as empty args
            args = DynamicMethod.NULL_ARGS;
        }
        Object[] newArgs = args;
        boolean argsCloned = false;
        // Starting from args.length + 1 as we must try to match against a case
        // where all specified args are fixargs, and the vararg portion 
        // contains zero args
outer:  for(int i = Math.min(args.length + 1, marshalTypes.length - 1); i >= 0; --i) {
            Class[] types = marshalTypes[i];
            if(types == null) {
                if(i == 0) {
                    return OverloadedDynamicMethod.NO_SUCH_METHOD;
                }
                continue;
            }
            // Marshal the arguments
            for(int j = 0; j < args.length; ++j) {
                // We're relying on i == types.length here
                Object dst = callProtocol.representAs(args[j], j < i ? types[j] : types[i - 1]);
                if(dst == Results.noAuthority || dst == Results.noRepresentation) {
                    continue outer; // Try a shorter signature, using more varargs and less fixargs
                }
                if(dst != newArgs[j]) {
                    if(!argsCloned) {
                        newArgs = args.clone();
                    }
                    newArgs[j] = dst;
                }
            }
            break;
        }
        
        ClassString<T> argTypes = new ClassString<T>(newArgs);
        Object objMember = selectorCache.get(argTypes);
        if(objMember == null) {
            objMember = argTypes.getMostSpecific(members);
            selectorCache.put(argTypes, objMember);
        }
        if(objMember instanceof Member) {
            T member = (T)objMember;
            newArgs = argPackers.get(member).packArgs(args, argsCloned, 
                    callProtocol);
            if(newArgs == null) {
                return OverloadedDynamicMethod.NO_SUCH_METHOD;
            }
            return new Invocation<T>(target, member, newArgs);
        }
        return objMember; // either NOT_FOUND or AMBIGUOUS
    }

    private static Class getMostSpecificCommonType(Class c1, Class c2) {
        if(c1 == c2) {
            return c1;
        }
        if(c2.isPrimitive()) {
            if(c2 == Byte.TYPE) c2 = Byte.class;
            else if(c2 == Short.TYPE) c2 = Short.class;
            else if(c2 == Character.TYPE) c2 = Character.class;
            else if(c2 == Integer.TYPE) c2 = Integer.class;
            else if(c2 == Float.TYPE) c2 = Float.class;
            else if(c2 == Long.TYPE) c2 = Long.class;
            else if(c2 == Double.TYPE) c2 = Double.class;
        }
        Set<Class> a1 = getAssignables(c1, c2);
        Set<Class> a2 = getAssignables(c2, c1);
        a1.retainAll(a2);
        if(a1.isEmpty()) {
            // Can happen when at least one of the arguments is an interface, as
            // they don't have Object at the root of their hierarchy
            return Object.class;
        }
        // Gather maximally specific elements. Yes, there can be more than one 
        // thank to interfaces. I.e., if you call this method for String.class 
        // and Number.class, you'll have Comparable, Serializable, and Object as 
        // maximal elements. 
        List<Class> max = new ArrayList<Class>();
outer:  for (Iterator iter = a1.iterator(); iter.hasNext();) {
            Class clazz = (Class) iter.next();
            for (Iterator maxiter = max.iterator(); maxiter.hasNext();) {
                Class maxClazz = (Class) maxiter.next();
                if(isMoreSpecific(maxClazz, clazz)) {
                    // It can't be maximal, if there's already a more specific
                    // maximal than it.
                    continue outer;
                }
                if(isMoreSpecific(clazz, maxClazz)) {
                    // If it's more specific than a currently maximal element,
                    // that currently maximal is no longer a maximal.
                    maxiter.remove();
                }
            }
            // If we get here, no current maximal is more specific than the
            // current class, so it is considered maximal as well
            max.add(clazz);
        }
        if(max.size() > 1) {
            return OBJECT_CLASS;
        }
        return max.get(0);
    }

    /**
     * Determines whether a type represented by a class object is 
     * convertible to another type represented by a class object using a 
     * method invocation conversion, without matching object and primitive
     * types. This method is used to determine the more specific type when
     * comparing signatures of methods.
     * @return true if either formal type is assignable from actual type, 
     * or formal and actual are both primitive types and actual can be
     * subject to widening conversion to formal.
     */
    private static boolean isMoreSpecific(Class<?> specific, Class<?> generic) {
        // Check for identity or widening reference conversion
        if(generic.isAssignableFrom(specific)) {
            return true;
        }
        // Check for widening primitive conversion.
        if(generic.isPrimitive()) {
            if(generic == Short.TYPE && (specific == Byte.TYPE)) {
                return true;
            }
            if(generic == Integer.TYPE && 
               (specific == Short.TYPE || specific == Byte.TYPE)) {
                return true;
            }
            if(generic == Long.TYPE && 
               (specific == Integer.TYPE || specific == Short.TYPE || 
                specific == Byte.TYPE)) {
                return true;
            }
            if(generic == Float.TYPE && 
               (specific == Long.TYPE || specific == Integer.TYPE || 
                specific == Short.TYPE || specific == Byte.TYPE)) {
                return true;
            }
            if(generic == Double.TYPE && 
               (specific == Float.TYPE || specific == Long.TYPE || 
                specific == Integer.TYPE || specific == Short.TYPE || 
                specific == Byte.TYPE)) {
                return true; 
            }
        }
        return false;
    }
    
    private static Set<Class> getAssignables(Class c1, Class c2) {
        Set<Class> s = new HashSet<Class>();
        collectAssignables(c1, c2, s);
        return s;
    }
    
    private static void collectAssignables(Class<?> c1, Class<?> c2, Set<Class> s) {
        if(c1.isAssignableFrom(c2)) {
            s.add(c1);
        }
        Class sc = c1.getSuperclass();
        if(sc != null) {
            collectAssignables(sc, c2, s);
        }
        Class[] itf = c1.getInterfaces();
        for(int i = 0; i < itf.length; ++i) {
            collectAssignables(itf[i], c2, s);
        }
    }

    private static Class[] getParameterTypes(Member member) {
        if(member instanceof Method) {
            return ((Method)member).getParameterTypes();
        }
        if(member instanceof Constructor) {
            return ((Constructor)member).getParameterTypes();
        }
        throw new AssertionError();
    }
    
    private static final class ClassString<T extends Member>
    {
        private final Class[] classes;
        
        ClassString(Object[] objects) {
            int l = objects.length;
            classes = new Class[l];
            for(int i = 0; i < l; ++i) {
                Object obj = objects[i];
                classes[i] = obj == null ? OBJECT_CLASS : obj.getClass();
            }
        }
        
        Class[] getClasses() {
            return classes;
        }
        
        public int hashCode() {
            int hash = 0;
            for(int i = 0; i < classes.length; ++i) {
                hash ^= classes[i].hashCode();
            }
            return hash;
        }
        
        public boolean equals(Object o) {
            if(o instanceof ClassString) {
                ClassString cs = (ClassString)o;
                if(cs.classes.length != classes.length) {
                    return false;
                }
                for(int i = 0; i < classes.length; ++i) {
                    if(cs.classes[i] != classes[i]) {
                        return false;
                    }
                }
                return true;
            }
            return false;
        }
        
        private static final int MORE_SPECIFIC = 0;
        private static final int LESS_SPECIFIC = 1;
        private static final int INDETERMINATE = 2;
        
        Object getMostSpecific(List<T> methods)
        {
            LinkedList<T> applicables = getApplicables(methods);
            if(applicables.isEmpty()) {
                return OverloadedDynamicMethod.NO_SUCH_METHOD;
            }
            if(applicables.size() == 1) {
                return applicables.getFirst();
            }
            LinkedList<T> maximals = new LinkedList<T>();
            for (T applicable : applicables)
            {
                Class[] appArgs = getParameterTypes(applicable);
                boolean lessSpecific = false;
                for (Iterator<T> maximal = maximals.iterator(); 
                    maximal.hasNext();)
                {
                    Member max = maximal.next();
                    Class[] maxArgs = getParameterTypes(max);
                    switch(moreSpecific(appArgs, maxArgs)) {
                        case MORE_SPECIFIC: {
                            maximal.remove();
                            break;
                        }
                        case LESS_SPECIFIC: {
                            lessSpecific = true;
                            break;
                        }
                    }
                }
                if(!lessSpecific) {
                    maximals.addLast(applicable);
                }
            }
            if(maximals.size() > 1) {
                return OverloadedDynamicMethod.AMBIGUOUS_METHOD;
            }
            return maximals.getFirst();
        }
        
        private static int moreSpecific(Class[] c1, Class[] c2) {
            boolean c1MoreSpecific = false;
            boolean c2MoreSpecific = false;
            final int cl1 = c1.length;
            final int cl2 = c2.length;
            final int m = Math.max(cl1, cl2);
            for(int i = 0; i < m; ++i) {
                Class class1 = getClass(c1, cl1, i);
                Class class2 = getClass(c2, cl2, i);
                if(class1 != class2) {
                    c1MoreSpecific = 
                        c1MoreSpecific ||
                        isMoreSpecific(class1, class2);
                    c2MoreSpecific = 
                        c2MoreSpecific ||
                        isMoreSpecific(class2, class1);
                }
            }
            if(c1MoreSpecific) {
                if(c2MoreSpecific) {
                    return INDETERMINATE;
                }
                return MORE_SPECIFIC;
            }
            if(c2MoreSpecific) {
                return LESS_SPECIFIC;
            }
            return INDETERMINATE;
        }
        
        private static Class getClass(Class[] classes, int l, int i) {
            return i < l - 1 ? classes[i] : classes[l - 1].getComponentType();
        }
        
        /**
         * Returns all methods that are applicable to actual
         * parameter classes represented by this ClassString object.
         */
        LinkedList<T> getApplicables(List<T> methods) {
            LinkedList<T> list = new LinkedList<T>();
            for (T member : methods) {
                if(isApplicable(member)) {
                    list.add(member);
                }
            }
            return list;
        }
        
        /**
         * Returns true if the supplied method is applicable to actual
         * parameter classes represented by this ClassString object.
         * 
         */
        private boolean isApplicable(T member) {
            final Class[] formalTypes = getParameterTypes(member);
            final int fl1 = formalTypes.length - 1;
            final int cl = classes.length;
            if(cl < fl1) {
                // less actual arguments than fix arguments of the method 
                return false;
            }
            for(int i = 0; i < fl1; ++i) {
                if(!isMethodInvocationConvertible(formalTypes[i], 
                        classes[i])) {
                    return false;
                }
            }
            Class varArgType = formalTypes[fl1].getComponentType();
            for(int i = fl1; i < cl; ++i) {
		if(!isMethodInvocationConvertible(varArgType, classes[i])) {
                    return false;
                }
            }
            return true;
        }
        
        /**
         * Determines whether a type represented by a class object is
         * convertible to another type represented by a class object using a 
         * method invocation conversion, treating object types of primitive 
         * types as if they were primitive types (that is, a Boolean actual 
         * parameter type matches boolean primitive formal type). This behavior
         * is because this method is used to determine applicable methods for 
         * an actual parameter list, and primitive types are represented by 
         * their object duals in reflective method calls.
         * @param formal the formal parameter type to which the actual 
         * parameter type should be convertible
         * @param actual the actual parameter type.
         * @return true if either formal type is assignable from actual type, 
         * or formal is a primitive type and actual is its corresponding object
         * type or an object type of a primitive type that can be converted to
         * the formal type.
         */
        private static boolean isMethodInvocationConvertible(Class<?> formal, Class<?> actual) {
            // Check for identity or widening reference conversion
            if(formal.isAssignableFrom(actual)) {
                return true;
            }
            // Check for boxing with widening primitive conversion. Note that 
            // actual parameters are never primitives.
            if(formal.isPrimitive()) {
                if(formal == Boolean.TYPE)
                    return actual == Boolean.class;
                if(formal == Character.TYPE)
                    return actual == Character.class;
                if(formal == Byte.TYPE && actual == Byte.class)
                    return true;
                if(formal == Short.TYPE &&
                   (actual == Short.class || actual == Byte.class))
                    return true;
                if(formal == Integer.TYPE && 
                   (actual == Integer.class || actual == Short.class || 
                    actual == Byte.class))
                    return true;
                if(formal == Long.TYPE && 
                   (actual == Long.class || actual == Integer.class || 
                    actual == Short.class || actual == Byte.class))
                    return true;
                if(formal == Float.TYPE && 
                   (actual == Float.class || actual == Long.class || 
                    actual == Integer.class || actual == Short.class || 
                    actual == Byte.class))
                    return true;
                if(formal == Double.TYPE && 
                   (actual == Double.class || actual == Float.class || 
                    actual == Long.class || actual == Integer.class || 
                    actual == Short.class || actual == Byte.class))
                    return true; 
            }
            return false;
        }
    }
}
