/*
   Copyright 2007 Attila Szegedi

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
package org.dynalang.mop.beans;

import java.lang.reflect.Constructor;
import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.lang.reflect.UndeclaredThrowableException;

import org.dynalang.mop.CallProtocol;

/**
 * TODO: rename "unwrap"
 * @author Attila Szegedi
 * @version $Id: $
 * @param <T>
 */
class OverloadedDynamicMethod<T extends Member> extends DynamicMethod
{
    static final Object NO_SUCH_METHOD = new Object();
    static final Object AMBIGUOUS_METHOD = new Object();
    
    private final OverloadedFixArgMethod<T> fixArgMethod = new OverloadedFixArgMethod<T>();
    private final String name;
    private OverloadedVarArgMethod<T> varArgMethod;
    
    OverloadedDynamicMethod(String name) {
        this.name = name;
    }
    
    @Override
    Object call(Object target, Object[] args, CallProtocol callProtocol) {
        // Try fixarg first
        Object invocation = fixArgMethod.createInvocation(target, args, callProtocol);
        if(invocation == NO_SUCH_METHOD) {
            if(varArgMethod != null) {
                invocation = varArgMethod.createInvocation(target, args, callProtocol);
            }
            if(invocation == NO_SUCH_METHOD) {
                throw new IllegalArgumentException("No signature of method " + 
                        name + " on " + getClassName(target) + 
                        " match the arguments");
            }
        }
        if(invocation == AMBIGUOUS_METHOD) {
            throw new IllegalArgumentException("Multiple signatures of method " + 
                    name + " on " + getClassName(target) + 
                    " match the arguments");
        }
        try {
            return ((Invocation)invocation).invoke();
        }
        catch(RuntimeException e) {
            throw e;
        }
        catch(Exception e) {
            throw new UndeclaredThrowableException(e);
        }
    }

    private static String getClassName(Object obj) {
        return obj == null ? "null" : obj.getClass().getName();
    }
    
    void addMember(T member) {
        fixArgMethod.addMember(member);
        boolean isVarArg;
        if(member instanceof Method) {
            isVarArg = ((Method)member).isVarArgs();
        }
        else if(member instanceof Constructor) {
            isVarArg = ((Constructor)member).isVarArgs();
        }
        else {
            throw new AssertionError();
        }
        if(isVarArg) {
            if(varArgMethod == null) {
                varArgMethod = new OverloadedVarArgMethod<T>();
            }
            varArgMethod.addMember(member);
        }
    }
    
}