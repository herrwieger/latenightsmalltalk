package org.dynalang.mop.impl;

import java.io.Serializable;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

import org.dynalang.mop.ClassBasedMetaobjectProtocol;
import org.dynalang.mop.CallProtocol;
import org.dynalang.mop.MetaobjectProtocol;

/**
 * A MOP that is composed of {@link ClassBasedMetaobjectProtocol} instances. 
 * Every operation is dispatched first to the the first member that claims
 * authority over the class of the target object. Only if it returns a 
 * non-authoritative answer will the others be attempted.
 * @author Attila Szegedi
 * @version $Id: $
 */
public class CompositeClassBasedMetaobjectProtocol implements ClassBasedMetaobjectProtocol, Serializable {
    private static final long serialVersionUID = 1L;

    // Used as a fail-fast in case none of the participating MOPs have 
    // authority over a class
    private static final ClassBasedMetaobjectProtocol[] NO_AUTHORITY = 
	new ClassBasedMetaobjectProtocol[0]; 

    private final ClassBasedMetaobjectProtocol[] members;
    
    private final Map<Class, ClassBasedMetaobjectProtocol[]> 
    	fastDelegationOrders = 
    	    new ConcurrentHashMap<Class, ClassBasedMetaobjectProtocol[]>();

    private final Map<ClassBasedMetaobjectProtocol, ClassBasedMetaobjectProtocol[]> 
    	delegationOrders = 
    	    new IdentityHashMap<ClassBasedMetaobjectProtocol, ClassBasedMetaobjectProtocol[]>();
    
    /**
     * Optimizes a list of MOPs. If a group of adjacent MOPs in the list all
     * implement {@link ClassBasedMetaobjectProtocol}, they will be replaced 
     * with a single instance of {@link CompositeClassBasedMetaobjectProtocol}
     * that contains them.
     * @param mops the list of MOPs to optimize
     * @return the optimized list
     */
    public static MetaobjectProtocol[] optimize(MetaobjectProtocol[] mops) {
	List<MetaobjectProtocol> lmops = new LinkedList<MetaobjectProtocol>();
	List<ClassBasedMetaobjectProtocol> cbmops = 
	    new LinkedList<ClassBasedMetaobjectProtocol>();
	for (MetaobjectProtocol protocol : mops) {
	    if(protocol instanceof ClassBasedMetaobjectProtocol) {
		cbmops.add((ClassBasedMetaobjectProtocol)protocol);
	    }
	    else {
		addClassBased(lmops, cbmops);
		lmops.add(protocol);
	    }
	}
	addClassBased(lmops, cbmops);
	return lmops.toArray(new MetaobjectProtocol[lmops.size()]);
    }
    
    private static void addClassBased(List<MetaobjectProtocol> lmops, List<ClassBasedMetaobjectProtocol> cbmops) {
	switch(cbmops.size()) {
	    case 0: {
		break;
	    }
	    case 1: {
		lmops.addAll(cbmops);
		lmops.clear();
		break;
	    }
	    default: {
		lmops.add(new CompositeClassBasedMetaobjectProtocol(
			cbmops.toArray(
				new ClassBasedMetaobjectProtocol[cbmops.size()])));
		cbmops.clear();
		break;
	    }
	}
    }

    /**
     * Creates a new composite class-based metaobject protocol from the 
     * specified members.
     * @param members the member metaobject protocols.
     */
    public CompositeClassBasedMetaobjectProtocol(ClassBasedMetaobjectProtocol[] members) {
	this.members = members.clone();
	final int l = members.length;
	for (int i = 0; i < l; i++) {
	    ClassBasedMetaobjectProtocol[] delegationOrder = new ClassBasedMetaobjectProtocol[l];
	    ClassBasedMetaobjectProtocol cbmop = members[i]; 
	    delegationOrder[0] = cbmop;
	    if(i > 0) {
		System.arraycopy(members, 0, delegationOrder, 1, i);
	    }
	    if(i < l - 1) {
		System.arraycopy(members, i + 1, delegationOrder, i + 1, l - 1 - i);
	    }
	    delegationOrders.put(cbmop, delegationOrder);
	}
    }
    
    private ClassBasedMetaobjectProtocol[] getDelegationOrder(Object obj) {
	return obj == null ? members : getDelegationOrder(obj.getClass());
    }

    private ClassBasedMetaobjectProtocol[] getDelegationOrder(Class clazz) {
	ClassBasedMetaobjectProtocol[] order = fastDelegationOrders.get(clazz);
	if(order == null) {
	    // Interrogate MOPs in order to see which has authority
    	    for (ClassBasedMetaobjectProtocol protocol : members) {
    		if(protocol.isAuthoritativeForClass(clazz)) {
    		    order = delegationOrders.get(protocol);
    		    break;
    		}
    	    }
    	    if(order == null) {
    		// None of the MOPs claims authority -- use fail-fast
    		order = NO_AUTHORITY;
    	    }
    	    fastDelegationOrders.put(clazz, order);
	}
	return order;
    }
    
    public boolean isAuthoritativeForClass(Class clazz) {
        return getDelegationOrder(clazz).length != 0;
    }
    
    public Object call(Object callable, CallProtocol callProtocol, Map args) {
	
        for (MetaobjectProtocol mop : getDelegationOrder(callable)) {
            Object res = mop.call(callable, callProtocol, args);
            if(res != Results.noAuthority) {
                return res;
            }
        }
        return Results.noAuthority;
    }

    public Object call(Object target, Object callableId, CallProtocol callProtocol, Map args) {
        for (MetaobjectProtocol mop : getDelegationOrder(target)) {
            Object res = mop.call(target, callableId, callProtocol, args);
            if(res != Results.noAuthority) {
                return res;
            }
        }
        return Results.noAuthority;
    }

    public Object call(Object target, Object callableId, CallProtocol callProtocol, Object... args) {
        for (MetaobjectProtocol mop : getDelegationOrder(target)) {
            Object res = mop.call(target, callableId, callProtocol, args);
            if(res != Results.noAuthority) {
                return res;
            }
        }
        return Results.noAuthority;
    }

    public Object call(Object callable, CallProtocol callProtocol, Object... args) {
        for (MetaobjectProtocol mop : getDelegationOrder(callable)) {
            Object res = mop.call(callable, callProtocol, args);
            if(res != Results.noAuthority) {
                return res;
            }
        }
        return Results.noAuthority;
    }

    public Results delete(Object target, long propertyId) {
        for (MetaobjectProtocol mop : getDelegationOrder(target)) {
            Results res = mop.delete(target, propertyId);
            if(res != Results.noAuthority) {
                return res;
            }
        }
        return Results.noAuthority;
    }

    public Results delete(Object target, Object propertyId) {
        for (MetaobjectProtocol mop : getDelegationOrder(target)) {
            Results res = mop.delete(target, propertyId);
            if(res != Results.noAuthority) {
                return res;
            }
        }
        return Results.noAuthority;
    }

    public Object get(Object target, long propertyId) {
        for (MetaobjectProtocol mop : getDelegationOrder(target)) {
            Object res = mop.get(target, propertyId);
            if(res != Results.noAuthority) {
                return res;
            }
        }
        return Results.noAuthority;
    }

    public Object get(Object target, Object propertyId) {
        for (MetaobjectProtocol mop : getDelegationOrder(target)) {
            Object res = mop.get(target, propertyId);
            if(res != Results.noAuthority) {
                return res;
            }
        }
        return Results.noAuthority;
    }

    public Boolean has(Object target, long propertyId) {
        for (MetaobjectProtocol mop : getDelegationOrder(target)) {
            Boolean has = mop.has(target, propertyId);
            if(has != null) {
                return has;
            }
        }
        return null;
    }

    public Boolean has(Object target, Object propertyId) {
        for (MetaobjectProtocol mop : getDelegationOrder(target)) {
            Boolean has = mop.has(target, propertyId);
            if(has != null) {
                return has;
            }
        }
        return null;
    }

    public Iterator<Entry> properties(Object target) {
	Iterator<Entry> compositeIt = null;
        for (MetaobjectProtocol mop : getDelegationOrder(target)) {
            Iterator<Entry> it = mop.properties(target);
    	    if(compositeIt == null) {
                compositeIt = it;
    	    }
    	    else if(compositeIt instanceof CompositeUniqueEntryIterator) {
    		((CompositeUniqueEntryIterator)compositeIt).add(it);
    	    }
            else {
                compositeIt = new CompositeUniqueEntryIterator(compositeIt, it);
            }
        }
        return compositeIt == null ? Collections.EMPTY_MAP.entrySet().iterator() : compositeIt;
    }

    public Iterator<? extends Object> propertyIds(Object target) {
	Iterator<? extends Object> compositeIt = null;
        for (MetaobjectProtocol mop : getDelegationOrder(target)) {
            Iterator<? extends Object> it = mop.propertyIds(target);
            assert it != null : mop.getClass().getName() + " returned null propertyIds iterator";
            if(compositeIt == null) {
        	compositeIt = it;
            }
            else if(compositeIt instanceof CompositeUniqueIterator) {
                ((CompositeUniqueIterator<Object>)compositeIt).add(it);
	    }
    	    else {
    	        compositeIt = new CompositeUniqueIterator<Object>(compositeIt, it);
    	    }
        }
        return compositeIt == null ? Collections.EMPTY_SET.iterator() : compositeIt;
    }

    public Results put(Object target, long propertyId, Object value, CallProtocol callProtocol) {
        for (MetaobjectProtocol mop : getDelegationOrder(target)) {
            Results res = mop.put(target, propertyId, value, callProtocol);
            if(res != Results.noAuthority) {
                return res;
            }
        }
        return Results.noAuthority;
    }

    public Results put(Object target, Object propertyId, Object value, CallProtocol callProtocol) {
        for (MetaobjectProtocol mop : getDelegationOrder(target)) {
            Results res = mop.put(target, propertyId, value, callProtocol);
            if(res != Results.noAuthority) {
                return res;
            }
        }
        return Results.noAuthority;
    }

    public Object representAs(Object object, Class targetClass) {
        for (MetaobjectProtocol mop : getDelegationOrder(object)) {
            Object res = mop.representAs(object, targetClass);
            if(res != Results.noAuthority) {
                return res;
            }
        }
        return Results.noAuthority;
    }
}
